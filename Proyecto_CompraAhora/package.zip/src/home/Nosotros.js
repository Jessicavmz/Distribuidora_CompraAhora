import React from 'react'
import './Nosotros.css';

export default function Nosotros() {
    return (
        <section id="nosotros" className='padded'>
            <div className="container">
                <h2>Nosotros</h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsa totam ipsum molestiae eum maiores minima quod, aliquam mollitia quae. Perspiciatis explicabo dicta dolores qui obcaecati id voluptas eius, eligendi illo tempore vero voluptatibus libero saepe asperiores excepturi officiis dolor reiciendis sequi doloribus! Velit nulla itaque eum maxime, facere voluptatibus optio facilis incidunt, reiciendis, nesciunt cumque eligendi odio sed impedit. Aperiam dicta quis a sequi necessitatibus officia ex iusto, ad porro, ipsa dolore autem accusantium nostrum sapiente dolorum temporibus eveniet, minus quasi dignissimos accusamus. Quisquam accusamus odit nulla nesciunt, cum distinctio omnis reprehenderit vel saepe et natus fugit doloremque molestiae officia dignissimos soluta animi deleniti excepturi maiores veritatis hic at voluptatum explicabo earum. Modi distinctio obcaecati neque libero nobis error laborum.</p>
            </div>
        </section>
    )
}

