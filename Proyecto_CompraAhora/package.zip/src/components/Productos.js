import React, { useEffect, useState } from 'react'
import './Productos.css';
import noImagen from './../assets/images/no-imagen.jpg';
import { ApiWebURL } from '../utils';
import { Link } from 'react-router-dom';

export default function Productos(props) {
    const [listaProductos, setListaProductos] = useState([]);
    const [itemProducto, setItemProducto] = useState([]);
    //console.log(props)
    useEffect(() => {
        leerServicio(props.categoriaProductos);
    }, [props.categoriaProductos]);

    const leerServicio = (idcategoria) => {
        const rutaServicio = ApiWebURL + "productos.php?idcategoria=" + idcategoria;
        fetch(rutaServicio)
            .then(response => response.json())
            .then(data => {
                //console.log(data);
                setListaProductos(data);
            });
    }

    const dibujarTabla = () => {
        return (
            <table className="table">
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Producto</th>
                        <th className="text-end">Precio S/</th>
                    </tr>
                </thead>
                <tbody>
                    {listaProductos.map(item =>
                        <tr key={item.idproducto}>
                            <td>{item.idproducto}</td>
                            <td>{item.nombre}</td>
                            <td className="text-end">
                                <span className='precio-lista'>
                                    {item.preciorebajado !== "0"
                                        ? parseFloat(item.precio).toFixed(2)
                                        : ""}
                                </span> {item.preciorebajado === "0"
                                    ? parseFloat(item.precio).toFixed(2)
                                    : parseFloat(item.preciorebajado).toFixed(2)}

                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        )
    }

    const dibujarCuadricula = () => {
        return (

            <div className="row row-cols-lg-4 row-cols-md-3 row-cols-sm-2 g-4" id="cards-productos">

                {listaProductos.map(item =>
                    <div className="col" key={item.idproducto}>
                        <div className="card">

                            <Link to={"/productodetalles/" + item.idproducto}>
                                <img src={item.imagenchica === null
                                    ? noImagen
                                    : ApiWebURL + item.imagenchica}
                                    className="card-img-top" alt="..." />
                            </Link>


                            <div className={item.preciorebajado === "0"
                                ? 'sin-oferta'
                                : 'con-oferta'}>
                                {Math.round((1 - parseFloat(item.preciorebajado) / (item.precio)) * 100)}%
                            </div>
                            <div className="card-body">
                                <h6 className="card-title">{item.nombre}
                                    <i className="bi bi-eye-fill btnVistaRapida" title='Vista rápida'
                                        data-bs-toggle="modal" data-bs-target="#vistaRapidaModal"
                                        onClick={() => mostrarVistaRapida(item.idproducto)}></i>
                                </h6>
                                <p className="card-text">S/ {item.preciorebajado === "0"
                                    ? parseFloat(item.precio).toFixed(2)
                                    : parseFloat(item.preciorebajado).toFixed(2)}
                                    <span className='precio-lista'>
                                        {item.preciorebajado !== "0"
                                            ? "S/" + parseFloat(item.precio).toFixed(2)
                                            : ""}
                                    </span>
                                </p>
                            </div>
                        </div>
                    </div>
                )}

            </div>

        )
    }

    const mostrarVistaRapida = (idproducto) => {
        //console.log(idproducto);
        const rutaServicio = ApiWebURL + "productos.php?idproducto=" + idproducto;
        fetch(rutaServicio)
            .then(response => response.json())
            .then(data => {
                //console.log(data);
                setItemProducto(data[0])
            });
    }

    const dibujarVistaRapida = () => {
        return (
            <div className="modal fade" id="vistaRapidaModal" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div className="modal-dialog modal-lg modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h1 className="modal-title fs-5" id="exampleModalLabel">{itemProducto.nombre}</h1>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div className="modal-body">
                            <div className="row">
                                <div className="col-md">
                                    <img src={itemProducto.imagengrande === null
                                        ? noImagen
                                        : ApiWebURL + itemProducto.imagengrande} alt="" className='img-fluid' />
                                </div>
                                <div className="col-md">
                                    <table className="table">
                                        <tbody>
                                            <tr><th>Detalle</th><td>{itemProducto.detalle}</td></tr>
                                            <tr><th>Precio</th><td>
                                                S/ {itemProducto.preciorebajado === "0"
                                                    ? parseFloat(itemProducto.precio).toFixed(2)
                                                    : parseFloat(itemProducto.preciorebajado).toFixed(2)}
                                                <span className='precio-lista'>
                                                    {itemProducto.preciorebajado !== "0"
                                                        ? "S/" + parseFloat(itemProducto.precio).toFixed(2)
                                                        : ""}
                                                </span>
                                            </td></tr>
                                            <tr><th>Categoría</th><td>{itemProducto.categoria}</td></tr>
                                            <tr><th>Proveedor</th><td>{itemProducto.proveedor}</td></tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                            <button type="button" className="btn btn-primary">Agregar al carrito</button>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    return (
        <>
            <ul className="nav nav-tabs" id="myTab" role="tablist">
                <li className="nav-item" role="presentation">
                    <button className="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#cuadricula-tab-pane" type="button" role="tab" aria-controls="home-tab-pane" aria-selected="true">
                        <i className="bi bi-grid-3x3-gap-fill"></i>
                    </button>
                </li>
                <li className="nav-item" role="presentation">
                    <button className="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#tabla-tab-pane" type="button" role="tab" aria-controls="profile-tab-pane" aria-selected="false">
                        <i className="bi bi-list"></i>
                    </button>
                </li>
            </ul>
            <div className="tab-content" id="myTabContent">
                <div className="tab-pane fade show active" id="cuadricula-tab-pane" role="tabpanel" aria-labelledby="home-tab" tabIndex="0">
                    {dibujarCuadricula()}
                </div>
                <div className="tab-pane fade" id="tabla-tab-pane" role="tabpanel" aria-labelledby="profile-tab" tabIndex="0">
                    {dibujarTabla()}
                </div>
            </div>
            {dibujarVistaRapida()}
        </>
    )
}
