import './App.css';
import MainHeader from './common/MainHeader';
import MainFooter from './common/MainFooter';
import MainNav from './common/MainNav';
import Inicio from './pages/Inicio';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Inversiones from './pages/Inversiones';
import Proveedores from './pages/Proveedores';
import Empleados from './pages/Empleados';
import Tienda from './pages/Tienda';
import ProductoDetalles from './pages/ProductoDetalles';


function App() {//Comentario JavaScript
  return (
    <>{/* Comentario */}
      <BrowserRouter>
        <MainHeader />
        <MainNav />
        <main id="main-content">

          <Routes>
            <Route path="/" element={<Inicio/>} />
            <Route path="/inversiones" element={<Inversiones/>} />
            <Route path="/proveedores" element={<Proveedores/>} />
            <Route path="/empleados" element={<Empleados/>} />
            <Route path="/tienda" element={<Tienda/>} />
            <Route path="/productodetalles/:idproducto" element={<ProductoDetalles/>} />
          </Routes>

        </main>
        <MainFooter />
      </BrowserRouter>
    </>
  );
}

export default App;